'use client' // This is likely a comment to indicate the type of environment or client being used.
import * as React from 'react'; // Importing React library for building UI components.
import CssBaseline from '@mui/material/CssBaseline'; // Importing CssBaseline component from Material-UI to reset browser styling.
import AppBar from '@mui/material/AppBar'; // Importing AppBar component from Material-UI for creating app bars.
import Toolbar from '@mui/material/Toolbar'; // Importing Toolbar component from Material-UI for a toolbar layout.
import Typography from '@mui/material/Typography'; // Importing Typography component from Material-UI for text styling.
import Button from '@mui/material/Button'; // Importing Button component from Material-UI for buttons.
import TextField from '@mui/material/TextField'; // Importing TextField component from Material-UI for input fields.
import IconButton from '@mui/material/IconButton'; // Importing IconButton component from Material-UI for icon buttons.
import SearchIcon from '@mui/icons-material/Search'; // Importing SearchIcon component from Material-UI for search icon.
import Box from '@mui/material/Box'; // Importing Box component from Material-UI for layout purposes.
import { ThemeProvider, createTheme } from '@mui/material/styles'; // Importing ThemeProvider and createTheme from Material-UI for theming.
import { green, grey } from '@mui/material/colors';
import {useState} from "react";
import Grid from "@mui/material/Grid";
import Container from "@mui/material/Container";
import {CircularProgress} from "@mui/material"; // Importing green and grey colors from Material-UI.

export default function FilmSearch() {
    const [searchTerm, setSearchTerm] = useState('');
    const [films, setFilms] = useState([]);
    const [loading, setLoading] = useState(false);

    const handleSearch = async () => {
        setLoading(true);
        try {
            const response = await fetch(`/api/getfilms?keyword=${encodeURIComponent(searchTerm)}`);
            const data = await response.json();
            setFilms(data);
        } catch (error) {
            console.error('Error fetching films:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Container>
            <Typography variant="h4" gutterBottom>
                Film Search
            </Typography>
            <Grid container spacing={2} alignItems="center">
                <Grid item xs={9}>
                    <TextField
                        fullWidth
                        label="Search for films"
                        variant="outlined"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </Grid>
                <Grid item xs={3}>
                    <Button
                        fullWidth
                        variant="contained"
                        color="primary"
                        onClick={handleSearch}
                        disabled={loading}
                    >
                        Search
                    </Button>
                </Grid>
            </Grid>
            {loading && <CircularProgress />}
            {!loading && films.length === 0 && <Typography variant="body1">No films found.</Typography>}
            {!loading && films.length > 0 && (
                <ul>
                    {films.map((film) => (
                        <li key={film._id}>
                            <Typography variant="body1">{film.title}</Typography>
                            <Typography variant="body2">{film.director}</Typography>
                        </li>
                    ))}
                </ul>
            )}
        </Container>
    );
}