// middleware/database.js

import { MongoClient } from 'mongodb';
import nextConnect from 'next-connect';
import dotenv from 'dotenv';

dotenv.config();

const MONGODB_URI = process.env.MONGODB_URI;
const databaseName = "film-findr";

const client = new MongoClient(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const middleware = nextConnect();

middleware.use(async (req, res, next) => {
    if (!client.isConnected()) await client.connect();
    req.dbClient = client;
    req.db = client.db(databaseName);
    return next();
});

export default middleware;
