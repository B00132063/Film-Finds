// pages/index.js

import Dashboard from '../app/dashboard';

const Home = () => {
    return (
        <Dashboard />
    );
};

export default Home;
